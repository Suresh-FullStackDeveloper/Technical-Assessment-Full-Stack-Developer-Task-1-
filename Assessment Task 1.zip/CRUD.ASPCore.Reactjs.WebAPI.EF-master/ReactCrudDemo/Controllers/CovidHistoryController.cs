﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using ReactCrudDemo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

using Newtonsoft.Json.Linq;
using RestSharp;

namespace ReactCrudDemo.Controllers
{
    [Route("api/[controller]")]
    //[ApiController]
    public class CovidHistoryController : ControllerBase
    {


        //CovidHistoryDataAccessLayer objemployee = new CovidHistoryDataAccessLayer();

        [HttpGet]
        [Route("api/CovidSummary/Index")]
        public TblCovidSummary Index()
        {
            var client = new RestClient("https://api.covid19api.com/summary");
            client.Timeout = -1;
            var request = new RestRequest(Method.GET);
            var response = client.Execute(request);
            return (TblCovidSummary)response;
        }

        

        //[HttpGet]
        //[Route("api/Employee/Details/{id}")]
        //public TblEmployee Details(int id)
        //{
        //    //return objemployee.GetEmployeeData(id);
        //}

    }
}
