﻿import * as React from 'react';
import { RouteComponentProps } from 'react-router';
import { Link, NavLink } from 'react-router-dom';

interface CovidSummaryDataState {
    CovidHistoryList: CovidSummaryData[];
    loading: boolean;
}

export class CovidSummary extends React.Component<RouteComponentProps<{}>, CovidSummaryDataState> {
    constructor() {
        super();
        this.state = { CovidHistoryList: [], loading: true };

        fetch('api/CovidSummary/Index')
            .then(response => response.json() as Promise<CovidSummaryData[]>)
            .then(data => {
                this.setState({ CovidHistoryList: data, loading: false });
            });

      

    }

    public render() {
        let contents = this.state.loading
            ? <p><em>Loading...</em></p>
            : this.renderCovidSummaryTable(this.state.CovidHistoryList);

        return <div>
            <h1>Covid Summary Data</h1>
            <p>This component demonstrates fetching Covid Summary data from the server.</p>
           
            {contents}
        </div>;
    }

    


    // Returns the HTML table to the render() method.
    private renderCovidSummaryTable(CovidHistoryList: CovidSummaryData[]) {
        return <table className='table'>
            <thead>
                <tr>
                    <th></th>
                    <th>Country</th>
                    <th>Country Code</th>
                    <th>Slug</th>
                    <th>New Confirmed</th>
                    <th>Total Confirmed</th>
                    <th>New Deaths</th>

                    <th>Total Deaths</th>
                    <th>New Recovered</th>
                    <th>Total Recovered</th>
                    <th>Date Time</th>
                </tr>
            </thead>
            <tbody>
                {CovidHistoryList.map(covhist =>
                    <tr key={covhist.country}>
                        <td></td>
                        <td>{covhist.countrycode}</td>
                        <td>{covhist.slug}</td>
                        <td>{covhist.newconfirmed}</td>
                        <td>{covhist.totalconfirmed}</td>
                        <td>{covhist.newdeaths}</td>

                        <td>{covhist.totaldeaths}</td>
                        <td>{covhist.newrecovered}</td>
                        <td>{covhist.totalrecovered}</td>
                        <td>{covhist.datetime}</td>
                       
                    </tr>
                )}
            </tbody>
        </table>;
    }
}

export class CovidSummaryData {
    //employeeId: number = 0;
    //name: string = "";
    //gender: string = "";
    //city: string = "";
    //department: string = "";

    country: string = "";
    countrycode: string = "";// { get; set; }

    slug: string = ""; //{ get; set; }   //  "": "chile",

    newconfirmed: number = 0;// { get; set; }

    totalconfirmed: number = 0;// { get; set; }

    newdeaths: number = 0;// { get; set; }

    totaldeaths: number = 0;// { get; set; }
    newrecovered: number = 0;// { get; set; }

    totalrecovered: number = 0;// { get; set; }

    datetime: any;//// { get; set; }
}

