# CRUD.ASPCore.Reactjs.WebAPI.EF
In this article, we are going to create a web application using ASP.NET Core 2.0 and React.js with the help of Entity Framework Core database first approach. We will be creating a sample Employee Record Management system and perform CRUD operations on it. To read the inputs from the user, we are using HTML Form element with required field validations on the client side. We are also going to bind a dropdown list in the HTML Form to a table in the database using EF Core.

We will be using Visual Studio 2017 and SQL Server 2014.
# Read the full article at
http://ankitsharmablogs.com/asp-net-core-crud-with-react-js-and-entity-framework-core/
