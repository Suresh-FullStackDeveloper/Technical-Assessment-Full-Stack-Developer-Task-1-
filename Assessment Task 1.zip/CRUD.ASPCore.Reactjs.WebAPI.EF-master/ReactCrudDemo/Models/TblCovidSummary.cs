﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ReactCrudDemo.Models
{
    public partial class TblCovidSummary
    {
        public string Country { get; set; }
        public string CountryCode { get; set; }

        public string Slug { get; set; }   //  "": "chile",

        public int NewConfirmed { get; set; }

        public int TotalConfirmed { get; set; }

        public int NewDeaths { get; set; }

        public int TotalDeaths { get; set; }
        public int NewRecovered { get; set; }

        public int TotalRecovered { get; set; }

        public DateTime Date { get; set; }
        //"Date": "2021-06-20T03:54:45.82Z",
        //"Premium": {}

    }
}
